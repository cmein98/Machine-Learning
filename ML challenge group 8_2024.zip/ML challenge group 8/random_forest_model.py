#!/usr/bin/env python
# coding: utf-8

# In[5]:


import pandas as pd
import logging
import json
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_absolute_error

#Loading the training data
def main():
    logging.getLogger().setLevel(logging.INFO)
#Loading the training data and filling the missing values with "Unknown"    
    logging.info("Loading training data")
    train = pd.DataFrame.from_records(json.load(open('train.json'))).fillna("Unknown")

#Additional data cleaning procedures
    train = train.drop(["editor"], axis=1)
    train = train.dropna()
    train = train.drop_duplicates(subset=['title'])
    year = train["year"]
    train = train.drop(["year"], axis=1)
    train = pd.get_dummies(train, columns=['ENTRYTYPE'])
    train['year'] = pd.to_numeric(year, errors='coerce').apply(round)
    train['author'] = train['author'].apply(lambda author: ', '.join(author))

#Splitting Validation Data    
    logging.info("Splitting validation")
    X = train.drop('year', axis=1)
    y = train['year']
    X_train, X_val, y_train, y_val = train_test_split(X, y, stratify=y, random_state=123)

#Feature engineering with updated transformations
    logging.info("Preparing ColumnTransformer")
    featurizer = ColumnTransformer(
        transformers=[
            ("title", TfidfVectorizer(), "title"),
            ("publisher", TfidfVectorizer(), "publisher"),
            ("author", TfidfVectorizer(), "author"),
            ("abstract", TfidfVectorizer(stop_words='english', min_df=5), "abstract"),
        ],
        remainder='drop'
    )

#Creating RF Regression pipeline
    rf_pipe = make_pipeline(featurizer, RandomForestRegressor(n_estimators=100,
                                                               max_features=None,
                                                               min_samples_split=2,
                                                               n_jobs=-1, warm_start=True, verbose=10))

    logging.info("Validation")
#Getting the best RF Regression model
    best_rf_model = rf_pipe.fit(X_train, y_train)

#Evaluating on validation data
    logging.info("Evaluating on validation data")
    err = mean_absolute_error(y_val, best_rf_model.predict(X_val))
    logging.info(f"Best Randomforest MAE: {err}")
#Loading the test data
    logging.info(f"Predicting on test")
    test = pd.DataFrame.from_records(json.load(open('test.json'))).fillna("Unknown")
    test['author'] = test['author'].apply(lambda author: ', '.join(author))

#Making predictions on the test set    
    pred = rf_pipe.predict(test)
    
#Writing the prediction file
    test['year'] = pred.round().astype(int)
    logging.info("Writing prediction file")
    test.to_json("predicted.json", orient='records', indent=2)

if __name__ == "__main__":
    main()


# In[7]:


import pandas as pd

# Load the predicted file
predicted_data = pd.read_json("predicted.json")

# Display the contents of the DataFrame
predicted_data.info()


# In[ ]:




